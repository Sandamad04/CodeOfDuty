<?php

include "config.php";

    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $username = $_POST['username'];
    $password = $_POST['password'];



    $sql = "INSERT INTO customer(name, phone, username, password) VALUES ('$name', '$phone', '$username','$password')";

    if ($conn->query($sql) === TRUE) {
        echo '<script>alert("Record Inserted successfully");
        window.location = "customer.php";
        </script>';
      } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
      }
      
      $conn->close();



?>