<?php
session_start();

if($_SESSION['user']){
    $uesr = $_SESSION['user'];
    
}
else{
    header("location: index.html"); 
}


include("config.php");


?>



<?php

if(isset($_GET['cusID']))
{
    $id = $_GET['cusID'];

    $sql = "DELETE FROM customer WHERE cusID = '$id'";

    if (mysqli_query($conn, $sql)) {
        echo '<script>alert("Record Deleted successfully");
        window.location = "customer.php";
        </script>';
        
        
      } else {
        echo "Error deleting record: " . mysqli_error($conn);
      }
      
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <link rel="stylesheet" href="style.css">
</head>
<body>
 <div class="sideBar">
    <div class="sideBarLogo">
        <h2>
            <label for=""><span><ion-icon name="call"></ion-icon></span>EMC Mobile</label>
        </h2>
    </div>

    <div class="sideBarMenu">
        <ul>
            <li>
                <a href="dashboard.php"><span><ion-icon name="home"></ion-icon></span>Dashboard</a>
            </li>

            <li>
                <a href="customer.php"><span><ion-icon name="person"></ion-icon></span>Customer</a>
            </li>

            <li>
                <a href="smartphone.php"><span><ion-icon name="phone-portrait"></ion-icon></span>Smartphone</a>
            </li>

            <li>
                <a href="accessories.php"><span><ion-icon name="build"></ion-icon></span>Accessories</a>
            </li>

            <li>
                <a href="branches.php"><ion-icon name="browsers"></ion-icon></span>Branches</a>
            </li>
            <li>
                <a href="#"><span><ion-icon name="logo-paypal"></ion-icon></span>Payments </a>
            </li>

            <li>
                <a href="index.html"><span><ion-icon name="home"></ion-icon></span>Log Out </a>
            </li>
        </ul>
    </div>
 </div>

 <div class="main">
    <header class="nav">
        <h2>
            <label for=""><span><ion-icon name="ellipsis-vertical"></ion-icon></span></label>
        </h2>

        <div class="searchBar">
            <span><ion-icon name="search"></ion-icon></span>
            <input type="search" name="" id="" placeholder="Search Here">
        </div>

        <div class="userBox">
            <img src="img/user.jpeg" alt="" width="60px" height="60px">
            <div class="userName">
                <h4 name="user">Mandara</h4>
                <small>Admin</small>
            </div>
        </div>
    </header>


<div class="mainBox">
    

    <div class="tableBox">
        <div class="boxTitle">
            <h2>accessories</h2>
            <button class="add"><a href="insertCus.php">Add New Order</button>
        </div>
        <table>
            <thead>
                <tr>
                    <td>First Name</td>
                    <td>Last Name</td>
                    <td>Age</td>
                    <td>country</td>
                    <td>gender</td>
                </tr>
            </thead>
            <tbody>

                <?php

                    include "config.php";
                    $sql = "SELECT * FROM customer order by cusID";
                    $result = mysqli_query($conn,$sql);

                    while($row = $result->fetch_assoc()) {

                    ?>
                    
                <tr>
                    <tr>
                        <td><?php echo $row['cusID']?></td>
                        <td><?php echo $row['name']?></td>
                        <td><?php echo $row['phone']?></td>
                        <td><?php echo $row['username']?></td>
                        <td> <a href="updatecus.php?cusID=<?php echo $row['cusID'];?>"><span><ion-icon name="create"></ion-icon></ion-icon></span></a><a href="customer.php?cusID=<?php echo $row['cusID'];?>"><span><ion-icon name="trash-outline"></ion-icon></span></a></td>
            
                    </tr>
                    
                </tr>

                <?php
                    }
                ?>
            </tbody>
        </table>
    </div>
 </div>
</div>

    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

</body>
</html>

