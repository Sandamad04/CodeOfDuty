<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "emc";


$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error){
    die("error connecting: ".$conn->connect_error);
}

?>