<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <link rel="stylesheet" href="style.css">
</head>
<body>
 <div class="sideBar">
    <div class="sideBarLogo">
        <h2>
            <label for=""><span><ion-icon name="call"></ion-icon></span>EMC Mobile</label>
        </h2>
    </div>

    <div class="sideBarMenu">
        <ul>
            <li>
                <a href="#"><span><ion-icon name="home"></ion-icon></span>Dashboard</a>
            </li>

            <li>
                <a href="orders.html"><ion-icon name="person"></ion-icon></span>   Customer</a>
            </li>

            <li>
                <a href="#"><ion-icon name="phone-portrait"></ion-icon></span>   Smartphone</a>
            </li>

            <li>
                <a href="#"><span><ion-icon name="build"></ion-icon></span>Accessories</a>
            </li>

            <li>
                <a href="addOder.html"><span><ion-icon name="browsers"></ion-icon></span>Branch</a>
            </li>
            <li>
                <a href="addOder.html"><span><ion-icon name="logo-paypal"></ion-icon></span>Payment</a>
            </li>
        </ul>
    </div>
 </div>

 <div class="main">
    <header class="nav">
        <h2>
            <label for=""><span><ion-icon name="ellipsis-vertical"></ion-icon></span>Dashboard</label>
        </h2>

        <div class="searchBar">
            <span><ion-icon name="search"></ion-icon></span>
            <input type="search" name="" id="" placeholder="Search Here">
        </div>

        <div class="userBox">
            <img src="img/user.jpeg" alt="" width="60px" height="60px">
            <div class="userName">
                <h4 name="user">Mandara</h4>
                <small>Admin</small>
            </div>
        </div>
    </header>


<div class="mainBox" >
    <div class="formBoxInser">
        <div class="fromValueInsert">
            <h2 class="Insert">Insert Customer Details</h2>
            <form action="addCus.php" method="post">
                <div class="inputBoxInsert">
                    <ion-icon name="person"></ion-icon>
                    <input type="text" name="name" required>
                    <label for="">Full Name</label>
                </div>
                <div class="inputBoxInsert">
                    <ion-icon name="call"></ion-icon>
                    <input type="text" name="phone" required>
                    <label for="">Phone Number</label>
                </div>

                <div class="inputBoxInsert">
                    <ion-icon name="person"></ion-icon>
                    <input type="text" name="username" required>
                    <label for="">Username</label>
                </div>

                <div class="inputBoxInsert">
                    <ion-icon name="lock-closed"></ion-icon>
                    <input type="password" name="password" required>
                    <label for="">Password</label>
                </div>

               

                <button class="InsertBtn">INSERT</button>
                
            </form>
        </div>
    </div>
</div>

    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>

</body>
</html>

